# configure service principal for Ansible
export AZURE_SUBSCRIPTION_ID="c87c3439-9474-4a2b-972f-106124cf6189"
export AZURE_CLIENT_ID="d1651b0a-e63a-4b6f-92a7-ebdc55e5d74a"
export AZURE_SECRET="zaALGoae:S[BhUgl0.xwPq1bBCwwq2+5"
export AZURE_TENANT="1dc9b339-fadb-432e-86df-423c38a0fcb8"
# configure service principal for Terraform
export ARM_SUBSCRIPTION_ID="c87c3439-9474-4a2b-972f-106124cf6189"
export ARM_CLIENT_ID="d1651b0a-e63a-4b6f-92a7-ebdc55e5d74a"
export ARM_CLIENT_SECRET="zaALGoae:S[BhUgl0.xwPq1bBCwwq2+5"
export ARM_TENANT_ID="1dc9b339-fadb-432e-86df-423c38a0fcb8"
#enable ansible pipelining
export ANSIBLE_SSH_PIPELINING=1
